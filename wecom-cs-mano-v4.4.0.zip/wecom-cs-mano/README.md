# 企业微信智能客服 V4

全自动 RPA 客服系统，监控企业微信外部群聊，智能回复客户消息。

## 一键安装

```bash
pip3 install mss pynput Pillow requests easyocr
```

## 配置 API Key

编辑 `config.json`，填入你的 DeepSeek API Key：

```json
"ai": {
    "api_key": "sk-你的key"
}
```

## 启动

```bash
python3 main.py
```

## 权限要求（macOS）

1. 系统设置 → 隐私 → 屏幕录制 → 勾选终端/iTerm
2. 系统设置 → 隐私 → 辅助功能 → 勾选终端/iTerm

## 详细文档

见 `SKILL.md`。
