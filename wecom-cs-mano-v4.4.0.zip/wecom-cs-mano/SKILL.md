---
name: wecom-cs-mano
description: "企业微信智能客服 V4 — 全自动 RPA 客服系统。监控企业微信外部群聊，自动识别带 (@微信) 标识的客户消息并 AI 回复。基于 mss + EasyOCR + pynput + DeepSeek API 的全自包含方案。"
version: 4.4.0
icon: 🤖
author: "惊蛰"
tags: [wecom, customer-service, rpa, easyocr, wechat]
setup:
  install_deps: |
    pip3 install mss pynput Pillow requests easyocr
  permissions:
    - 屏幕录制权限（macOS 系统设置 → 隐私与安全性 → 屏幕录制）
    - 辅助功能权限（macOS 系统设置 → 隐私与安全性 → 辅助功能）
  env_vars:
    - DEEPSEEK_API_KEY: DeepSeek API 密钥（或在 config.json 中设置）
---

# 企业微信智能客服 V4（全自动版）

> 监控企业微信外部群聊，自动回复带 `(@微信)` 标识的客户消息

基于 **mss 截图 + PIL 红点检测 + EasyOCR 文字识别 + DeepSeek API 回复 + pynput 键鼠控制**，全自包含，无需外部 cron job 或视觉模型 API。

## 快速安装

```bash
# 1️⃣ 安装依赖
pip3 install mss pynput Pillow requests easyocr

# 2️⃣ 设置 API Key（二选一）
# 方式 A：写入环境变量
echo 'export DEEPSEEK_API_KEY="sk-你的key"' >> ~/.zshrc
source ~/.zshrc

# 方式 B：编辑 config.json
# 打开 config.json，修改 ai.api_key 字段

# 3️⃣ 启动
python3 main.py
```

## 前置条件

| 条件 | 说明 |
|------|------|
| macOS 系统 | 需要 AppleScript 获取窗口坐标 |
| 企业微信已登录 | 进程名「企业微信」（macOS 中文版） |
| 已在「外部群聊」视图 | 企业微信第一列底部进入「外部群聊」 |
| 屏幕录制权限 | 用于截图（mss 需要） |
| 辅助功能权限 | 用于模拟键盘鼠标（pynput 需要） |
| DeepSeek API Key | AI 回复使用 DeepSeek Chat |

## 工作原理

```
每 3 秒截图第二列（群聊列表）
        ↓
PIL 像素扫描检测红色未读圆点
        ↓
  有红点？──否──→ 继续等待
        ↓ 是
去重检查（图片哈希，防重复处理）
        ↓
点击群聊行进入会话（红点左偏移）
        ↓ 等待 1.5 秒
截图第三列会话窗口
        ↓
EasyOCR 提取文字（本地运行，支持中文）
        ↓
DeepSeek API 生成智能回复
        ↓
pynput 模拟键盘发送消息
        ↓
冷却 → 回到监控循环
```

### 企业微信三列布局

```
┌──────────────┬──────────────┬─────────────────────┐
│  第一列       │  第二列       │  第三列              │
│  功能列表     │  群聊列表     │  会话窗口            │
│              │              │                     │
│ 📌外部群聊    │ 🏠施工群 🔴  │ 张三(@微信): 你好   │
│  通讯录       │ 🏠设计群     │  什么时候能来量房？  │
│  工作台       │ 🏠业主群     │                     │
│              │              │  输入框...           │
└──────────────┴──────────────┴─────────────────────┘
    0% ~ 15%      15% ~ 38.7%     38.7% ~ 100%
```

**只检测第二列红点，只回复带 `(@微信)` 标识的客户消息。**

## 配置文件 (`config.json`)

```json
{
  "check_interval_seconds": 3,
  "wecom_process_name": "企业微信",
  "logging": {
    "log_file": "logs/monitor.log"
  },
  "ai": {
    "provider": "deepseek",
    "model": "deepseek-chat",
    "base_url": "https://api.deepseek.com",
    "api_key": "",
    "system_prompt": "你是企业微信智能客服「快亮家装饰」的AI助手。语气友好专业，简洁高效。回复不超过100字。只回复带有「(@微信)」标识的客户消息。结尾加上「(@微信)」标识。"
  }
}
```

**配置项说明：**

| 配置 | 默认值 | 说明 |
|------|--------|------|
| `check_interval_seconds` | 3 | 截图检测间隔（秒） |
| `wecom_process_name` | 企业微信 | 企业微信进程名 |
| `ai.api_key` | "" | 留空则从 Hermes 配置读取 |
| `ai.model` | deepseek-chat | AI 模型 |
| `ai.system_prompt` | (见上) | AI 回复风格提示词 |

## 文件结构

```
wecom-cs-mano/
├── SKILL.md              # 技能文档（本文件）
├── main.py               # 主程序入口
├── config.json            # 配置文件
├── requirements.txt       # Python 依赖
├── start.sh               # 启动脚本
├── mano/
│   ├── capture.py         # mss 截图模块
│   └── executor.py        # pynput 键鼠控制
├── src/
│   ├── message_detector.py  # 红点检测 + 窗口定位
│   ├── reply_generator.py   # AI 回复生成
│   ├── vision_analyzer.py   # OCR 文字提取
│   ├── wecom_controller.py  # 企业微信操作逻辑
│   └── window_manager.py    # 窗口管理
├── scripts/
│   └── kb_client.py         # 知识库客户端
├── knowledge_base/          # 知识库目录（可扩展）
└── logs/                    # 日志目录
```

## 运行命令

```bash
# 前台运行（看实时输出）
cd wecom-cs-mano && python3 main.py

# 后台运行
nohup python3 main.py > logs/output.log 2>&1 &

# 查看日志
tail -f logs/monitor.log

# 停止
pkill -f "python3 main.py"
```

## 常见问题

### 窗口检测不到
```bash
# 测试 AppleScript 窗口定位
osascript -e 'tell application "System Events" to tell process "企业微信" to if exists window 1 then get {position of window 1, size of window 1}'
```
**注意：** macOS 版企业微信进程名是中文「企业微信」，不是 "WeCom"。

### 红点误触
脚本已内置防护机制：
- 截图只截第二列区域（窗口 15%~38.7%），不包含第一列
- 多个红点时取最右侧的（避免误点第一列功能按钮）
- 点击位置有安全边界保护

### 回复发不出去
脚本采用「两次点击」策略：
1. 先点击会话窗口中间激活
2. 再点击输入框粘贴发送

如果仍然无效，检查企业微信窗口是否有遮挡或最小化。

### EasyOCR 报错
EasyOCR `readtext()` 不接受 PIL Image，必须转 numpy array：
```python
import numpy as np
result = reader.readtext(np.array(image))
```

模型首次运行自动下载（约 100MB），缓存于 `~/.EasyOCR/model/`。

## 故障排查

| 症状 | 可能原因 | 解决 |
|------|---------|------|
| 无反应 | 权限不足 | 检查屏幕录制 + 辅助功能权限 |
| 不进群 | 红点参数不对 | 调整 `RED_R_MIN` / `RED_GB_MAX` |
| OCR 乱码 | 窗口被遮挡 | 确保企业微信窗口在最前 |
| API 报错 | Key 未设置 | 检查 config.json 或环境变量 |

## 更新日志

- **v4.4.0** — 输入框点击修复 + AI 知识库
- **v4.3.0** — 列布局精密校准（15%/23.7%/61.3%）
- **v4.2.0** — 简化流程，移除冗余步骤
- **v4.1.0** — 红点误触修复，选右策略
- **v4.0.0** — 全自动版首发（EasyOCR + DeepSeek API）
